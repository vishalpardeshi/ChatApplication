<script>
 export default {

 }
</script>

<template>
  <div class="wrapper" id="dashboard-wrapper">
    <p>Welcome To Dashboard</p>
  </div>
</template>
